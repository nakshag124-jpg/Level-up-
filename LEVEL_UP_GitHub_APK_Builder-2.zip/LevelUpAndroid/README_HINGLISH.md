# LEVEL UP Android APK project

Ye ready-to-open Android Studio project aapke LEVEL UP HTML routine tracker ko Android WebView app mein chalata hai.

## APK banane ke steps (Windows / Mac / Linux)

1. ZIP extract karo.
2. Android Studio install/open karo: https://developer.android.com/studio
3. Welcome screen par **Open** dabao aur extracted `LevelUpAndroid` folder select karo.
4. Android Studio ko Gradle sync/download complete karne do. Internet connection zaroori ho sakta hai.
5. Agar JDK ka prompt aaye, Android Studio ka **Embedded JDK** select karo.
6. Menu se **Build > Build Bundle(s) / APK(s) > Build APK(s)** choose karo.
7. Build complete hone par notification mein **locate** dabao.
8. APK yahan milega: `app/build/outputs/apk/debug/app-debug.apk`
9. APK ko apne Android phone mein bhejo, file open karo, aur Android prompt par install permission allow karke install kar do.

## Phone par USB se test (optional)

1. Phone mein Developer options enable karo (Settings > About phone > Build number ko 7 baar tap).
2. Developer options mein USB debugging on karo.
3. USB cable se phone connect karo.
4. Android Studio mein Run (▶) dabao aur apna phone select karo.

## App details

- HTML UI Android app ke assets mein bundled hai; routine screen offline kaam karti hai.
- JavaScript + DOM storage enabled hain, taaki checklist browser storage mein save ho.
- Ask ChatGPT external browser kholta hai; iske liye internet chahiye.
- App ka application ID: `com.levelup.routinetracker`

## Important

- Ye personal testing ke liye debug APK banane ka project hai. Debug APK Android Studio automatically sign karta hai.
- Google Play ya public distribution ke liye signed release APK / Android App Bundle banana hoga.
- App uninstall ya app data clear karne par locally saved routine data delete ho sakta hai.
